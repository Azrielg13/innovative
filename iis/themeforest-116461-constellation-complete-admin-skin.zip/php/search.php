<!--

This is a dummy page for the search result function.

To enable search, create your own script using the var $_POST['s'] sent by the search form.

--><h2>Website pages</h2>
<p class="results-count"><strong>1</strong> match</p>
<ul class="small-files-list icon-xml">
	<li>
		<a href="#">How to create an <strong>add</strong>-on<br>
		<small><strong>Author:</strong> John Doe</small></a>
	</li>
</ul>

<hr>

<h2>Images</h2>
<p class="results-count"><strong>1</strong> match</p>
<ul class="small-files-list icon-img">
	<li>
		<a href="#">Create_<strong>add</strong>-on_illustration_1.jpg<br>
		<small><strong>Size:</strong> 320x240</small></a>
	</li>
</ul>